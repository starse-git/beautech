import React from 'react'
import TitleEngJPComponent from '../common/TitleEngJPComponent';

const NewsSectionComponent = () => {
  return (
    <div>
      <TitleEngJPComponent titleEn1="OUR" titleJp="ビューテックのしごと">
        <span className="text-pinkBrand">B</span>USINESS
      </TitleEngJPComponent>
      <TitleEngJPComponent titleEn1="" titleJp="ビューテックからのお知らせ">
        <span className="text-pinkBrand">N</span>EWS
      </TitleEngJPComponent>
    </div>
  )
}

export default NewsSectionComponent;