import React from 'react'

const RecruitSectionComponent = () => {
  return (
    <div>
      <h2>Recruit</h2>
    </div>
  )
}

export default RecruitSectionComponent;
