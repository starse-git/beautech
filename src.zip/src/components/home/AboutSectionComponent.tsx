import React from 'react'

const AboutSectionComponent = () => {
  return (
    <div>
      <h2>About</h2>
    </div>
  )
}

export default AboutSectionComponent;
