import NewsSectionComponent from "@/components/home/NewsSectionComponent";
import PublicLayout from "@/components/layouts/PublicLayout";
// import Image from "next/image";

export default function Home() {
  return (
    <div className="w-full">
      <PublicLayout>
        <h1>Home</h1>
        <NewsSectionComponent />
      </PublicLayout>
    </div>
  );
}
